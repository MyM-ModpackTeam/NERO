SPHAX PUREBDCRAFT
Texture pack for Minecraft NERO

--->>>Compilation created by SirWill from MineYourMind.net<<<---
_________________________________________

Installation instructions:

1. Download the NERO Patch and Sphax PureBDcraft Texture Pack from the bdcraft.net forum.
2. Launch the modpack and click "Resource Packs" -> "Open resource pack folder".
3. Drag and drop both downloaded zip files into the folder.
4. Enable both packs and enjoy it! ;)
_________________________________________

Credits:

http://bdcraft.net/community/pbdc-patches-rel-packs/minecraft-nero-t5474.html